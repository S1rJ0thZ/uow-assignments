from abc import ABC, abstractmethod
from datetime import datetime


class Observer(ABC):  # as an interface
    @abstractmethod
    def update(self, **kwargs):
        pass


class Subject(ABC):  # as an interface
    @abstractmethod
    def notifyObserver(self):
        pass


class Course:
    def __init__(self, code, name, cost):
        pass

    @property
    def code(self):
        pass

    @property
    def cost(self):
        pass

    def __str__(self):
        pass


class TeachingStaff(Observer):
    def __init__(self, staff_id, name, rate):
        pass

    @property
    def rate_per_day(self):
        pass

    @rate_per_day.setter
    def rate_per_day(self, newRate):
        pass

    # Q4
    def update(self, **kwargs):
        pass

    def __str__(self):
        pass


class CourseOffering(Subject):
    _sch_id = 1

    def __init__(self, course, instructors, start_date, days):
        pass

    @classmethod
    def change_sch_id(cls, new_id):
        pass

    @property
    def schedule_id(self):
        pass

    @property
    def start_date(self):
        pass

    @start_date.setter
    def start_date(self, new_start_date):
        pass

    def get_course_fee(self):
        pass

    # Q4
    def notifyObserver(self):
        pass

    def __str__(self):
        pass


def main():
    c1 = Course("Prog101", "Python Programming", 2000)
    c2 = Course("DB102", "All about Database", 1800)
    inst1 = TeachingStaff("IT101", "Jed Lee", 800)
    inst2 = TeachingStaff("IT103", "James Wong", 850)
    co1 = CourseOffering(c1, [inst1, inst2], datetime(2024, 11, 23), 3)
    co2 = CourseOffering(c2, [inst2], datetime(2024, 11, 22), 5)

    co1.start_date = datetime(2024, 11, 24)
    co2.start_date = datetime(2024, 11, 23)


main()
#Expected output
"""
Please note the start date for Prog101_1 is now 2024-11-24 00:00:00
Please note the start date for Prog101_1 is now 2024-11-24 00:00:00
Please note the start date for DB102_2 is now 2024-11-23 00:00:00
"""
