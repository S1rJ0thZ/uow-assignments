class Course:
    def __init__(self, code, name, cost):
        pass

    @property
    def code(self):
        pass

    @property
    def cost(self):
        pass

    def __str__(self):
        pass


class TeachingStaff:
    def __init__(self, staff_id, name, rate):
        pass

    @property
    def rate_per_day(self):
        pass

    @rate_per_day.setter
    def rate_per_day(self, newRate):
        pass

    def __str__(self):
        pass


class CourseOffering:
    _sch_id = 1

    def __init__(self, course, instructors, start_date, days):
        pass

    @classmethod
    def change_sch_id(cls, new_id):
        pass

    @property
    def schedule_id(self):
        pass

    @property
    def start_date(self):
        pass

    @start_date.setter
    def start_date(self, new_start_date):
        pass

    def get_course_fee(self):
        pass

    def __str__(self):
        pass


from abc import ABC, abstractmethod


class Customer(ABC):
    def __init__(self, email, name):
        pass

    @property
    def email(self):
        pass

    @abstractmethod
    def get_discount(self):
        pass

    def __str__(self):
        pass


class Corporate(Customer):
    _discount = 0.3

    def __init__(self, email, name, company, is_civil_servant):
        pass

    def get_discount(self):
        pass

    def __str__(self):
        pass


class Individual(Customer):
    _senior_discount = 0.5

    def __init__(self, email, name, dob):
        pass

    def _is_senior(self):
        pass

    def get_discount(self):
        pass

    def __str__(self):
        pass


class EnrolmentException(Exception):
    pass


from datetime import datetime, timedelta


class Enrolment:
    _id = 1

    def __init__(self, customer, course_offering):
        pass

    @ property
    def enrolment_id(self):
        pass

    @ property
    def customer_email(self):
        pass

    @ property
    def schedule_id(self):
        pass

    @ property
    def start_date(self):
        pass

    def get_course_fee(self):
        pass

    def __str__(self):
        pass


class Admin:
    def __init__(self, name):
        pass

    def enrol(self, enrolment):
        pass

    def withdraws(self, enrolment_id):
        pass


def main():
    try:
        ad = Admin("2024-Apr")
        c1 = Course("Prog101", "Python Programming", 2000)
        c2 = Course("DB102", "All about Database", 1800)
        inst1 = TeachingStaff("IT101", "Jed Lee", 800)
        inst2 = TeachingStaff("IT103", "James Wong", 850)
        co1 = CourseOffering(c1, [inst1, inst2], datetime(2024, 11, 23), 3)
        co2 = CourseOffering(c2, [inst2], datetime(2024, 11, 22), 5)
        cust1 = Individual("t1@email.com", "Test 1", datetime(1990, 1, 3))
        cust2 = Individual("t2@email.com", "Test 2", datetime(1965, 4, 5))
        cust3 = Corporate("t3@email.com", "Test 3", "ThatCompany", True)
        cust4 = Corporate("t4@email.com", "Test 4", "ThisCompany", False)
        for co in [co1, co2]:
            for c in [cust1, cust2, cust3, cust4]:
                e = Enrolment(c, co)
                ad.enrol(e)
                print(e.enrolment_id, e.schedule_id, e.customer_email,
                      e.get_course_fee())
        ad.withdraws(11)
    except Exception as e:
        print(e)


main()
#Expected output
"""
1 Prog101_1 t1@email.com 3475.0
2 Prog101_1 t2@email.com 3475.0
3 Prog101_1 t3@email.com 4170.0
4 Prog101_1 t4@email.com 4865.0
5 DB102_2 t1@email.com 3025.0
6 DB102_2 t2@email.com 3025.0
7 DB102_2 t3@email.com 3630.0
8 DB102_2 t4@email.com 4235.0
Enrolment not found!
"""
